import json
import requests
from bs4 import BeautifulSoup
import re
import sys
sys.stdout.reconfigure(encoding='utf-8')

url = "https://www.mykingdom.com.vn/products/sieu-xe-sang-trong-honda-civic-fd2-type-r-hot-wheels-jbk53-fpy86"

response = requests.get(url)
soup = BeautifulSoup(response.content, "html.parser")

# 1️⃣ Lấy danh sách ảnh phụ
images = []
for item in soup.find_all('div', class_='product__media media media--transparent'):
    img_tag = item.find('img')
    if img_tag and img_tag.get('src'):
        img_url = "https:" + img_tag['src'].strip()
        images.append(img_url)

# 2️⃣ Lấy tiêu đề và link sản phẩm
title_tag = soup.find('div', class_='product__title')
title = title_tag.find('h1').text.strip() if title_tag and title_tag.find('h1') else None
url_tag = title_tag.find('a', class_='product__title') if title_tag else None
url = "https://www.mykingdom.com.vn" + url_tag['href'] if url_tag else None

# 3️⃣ Lấy mô tả chi tiết sản phẩm
desc_tag = soup.find('div', class_='product-detail__product-description-content')
description = ""
if desc_tag:
    paragraphs = [p.get_text(strip=True) for p in desc_tag.find_all(['h2', 'p'])]
    description = "\n".join(paragraphs)

# 4️⃣ Lấy dữ liệu từ thẻ script
script_tag = soup.find('script', class_='swym-product-view-snippet')
script_content = script_tag.string if script_tag else ""

price_match = re.search(r'pr\s*:\s*([\d\/\.]+)', script_content)
stock_match = re.search(r'stk\s*:\s*(\d+)', script_content)
image_match = re.search(r'piu\s*=\s*"([^"]+)"', script_content)
url_match = re.search(r'du\s*:\s*"([^"]+)"', script_content)

# 5️⃣ Lấy phần “Thông tin sản phẩm”
info_div = soup.find('div', class_='custom-table-product product__description')
info = {}
if info_div:
    for item in info_div.find_all('div', class_='item'):
        title_info = item.find('div', class_='title')
        content_info = item.find('div', class_='content')
        if title_info and content_info:
            info[title_info.get_text(strip=True)] = content_info.get_text(strip=True)

# 6️⃣ Gom dữ liệu sản phẩm
product_data = {
    "title": title,
    "url": url_match.group(1) if url_match else url,
    "price": eval(price_match.group(1)) if price_match else None,
    "stock": int(stock_match.group(1)) if stock_match else None,
    "main_image": image_match.group(1) if image_match else None,
    "images": images,
    "description": description,
    "information": info
}

# 7️⃣ Xuất ra JSON đẹp
print(json.dumps(product_data, indent=4, ensure_ascii=False))
