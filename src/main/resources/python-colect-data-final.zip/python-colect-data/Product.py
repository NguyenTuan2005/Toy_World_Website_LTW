import requests
from bs4 import BeautifulSoup
import re
import random

class ProductScraper:
    def __init__(self, url: str):
        self.__source_url = url
        self.__soup = None
        self.__id = None
        self.__images = []
        self.__images_id = None
        self.__name = None
        self.__description = ""
        self.__info = {}
        self.__price = None
        self.__quantity = None

    def fetch(self):
        resp = requests.get(self.__source_url)
        resp.raise_for_status()
        self.__soup = BeautifulSoup(resp.content, "html.parser")

    def parse(self):
        for item in self.__soup.find_all('div', class_='product__media media media--transparent'):
            img_tag = item.find('img')
            if img_tag and img_tag.get('src'):
                img_url = "https:" + img_tag['src'].strip()
                self.__images.append(img_url)

        title_tag = self.__soup.find('div', class_='product__title')
        self.__name = title_tag.find('h1').text.strip() if title_tag and title_tag.find('h1') else None

        desc_tag = self.__soup.find('div', class_='product-detail__product-description-content')
        if desc_tag:
            paragraphs = [p.get_text(strip=True) for p in desc_tag.find_all(['h2', 'p'])]
            self.__description = "\n".join(paragraphs)

        span_price = self.__soup.find('span', class_='price-item price-item--regular')
        price = None
        if span_price:
            price_text = span_price.get('data-price') or span_price.get_text(strip=True)
            digits = re.sub(r'\D', '', price_text)
            price = int(digits) if digits else None

        info_div = self.__soup.find('div', class_='custom-table-product product__description')
        info = {}
        if info_div:
            for item in info_div.find_all('div', class_='item'):
                title_info = item.find('div', class_='title')
                content_info = item.find('div', class_='content')
                if title_info and content_info:
                    info[title_info.get_text(strip=True)] = content_info.get_text(strip=True)

        self.__price = price
        self.__quantity = str(random.randint(1, 100))
        self.__info = info

    def _sql_escape(self, s):
        return str(s).replace("'", "''")

    def write(self, product_output: str, assets_output: str):
        if self.__info:
            pairs = []
            for k, v in self.__info.items():
                pairs.append(f"'{self._sql_escape(k)}', '{self._sql_escape(v)}'")
            rest_info_sql = f"JSON_OBJECT({', '.join(pairs)})"
        else:
            rest_info_sql = 'NULL'
        id_sql = str(self.__id)
        price_sql = str(self.__price) if self.__price is not None else 'NULL'
        quantity_sql = str(self.__quantity)
        name_sql = f"'{self._sql_escape(self.__name)}'" if self.__name else 'NULL'
        description_sql = f"'{self._sql_escape(self.__description)}'" if self.__description else 'NULL'


        products_values = ", ".join([
            id_sql,  # id
            price_sql,  # price
            'NULL',  # promotion_id (placeholder)
            quantity_sql,  # quantity
            name_sql,  # name
            rest_info_sql,  # rest_info (JSON_OBJECT or NULL)
            description_sql,  # description
            "?",
            "?"
        ])

        products_insert_sql = (
            "INSERT INTO `products` "
            "(`id`, `price`, `promotion_id`, `quantity`, `name`, `rest_info`, `description`, `brand_id`, `category_id`)\n"
            f"VALUES\n    ({products_values});\n"
            "\n"
        )

        assets_rows = []
        for i, img in enumerate(self.__images, start=self.__images_id):
            img_path = self._sql_escape(img)
            assets_rows.append(f"({i}, '{img_path}', {self.__id})")
            self.__images_id = i
        if assets_rows:
            assets_insert_sql = (
                    "INSERT INTO `product_assets` "
                    "(`id`, `img_path`, `product_id`)\n"
                    "VALUES\n    " + ",\n    ".join(assets_rows) + ";\n"
                    "\n"
            )
        else:
            assets_insert_sql = "-- No product assets to insert.\n"

        with open(product_output, 'a', encoding='utf-8') as f:
            if products_insert_sql and not products_insert_sql.endswith('\n'):
                products_insert_sql += '\n'
            f.write(products_insert_sql)

        with open(assets_output, 'a', encoding='utf-8') as f:
            if assets_insert_sql and not assets_insert_sql.endswith('\n'):
                assets_insert_sql += '\n'
            f.write(assets_insert_sql)

    def write_all(self, urls_src: str, product_output: str, assets_output: str):
        with open(urls_src, 'r', encoding='utf-8') as f:
            urls = [line.strip() for line in f if line.strip()]

        self.__images_id = 0
        for i, url in enumerate(urls, start=1):
            self.__images_id += 1
            self.__id = i
            self.__source_url = url
            self.__images = []
            self.fetch()
            self.parse()
            self.write(product_output, assets_output)


if __name__ == '__main__':
    product = ProductScraper(url=None)
    product.write_all(urls_src="product_links"
                      ,product_output="product_insert.txt"
                      , assets_output="asset_insert.txt")